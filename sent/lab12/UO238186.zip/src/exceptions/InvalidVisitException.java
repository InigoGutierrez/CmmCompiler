package exceptions;

public class InvalidVisitException extends RuntimeException {

    public InvalidVisitException(String message) {
        super(message);
    }

}
